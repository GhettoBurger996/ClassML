__author__ = 'adrianrosebrock'

# import the necessary packages
from .rgbhistogram import RGBHistogram